#pragma once

//no ponto .h é o que?
//o que as funções terão
//aqui não há implementação
//somente protótipos das funções
//aqui indica o que estará disponível para o programador
//ou programadora utilizar deste arquivo .h
//lembre da aula que este arquivo.h é chamado de header file
//até agora você usou header files criados por outroas programadores
//agora você seu próprio header file.
//Mas você precisa implementar as funções em algum lugar
//e ai que entra o .cpp
//protótipos das funções
void ExibirMenu();
int RetornarEscolha();
int ProcessarEscolha(int TipoEscolha);