#pragma once
namespace mat02
{
	float Soma(int Num1, int Num2)
	{
		return (Num1 + (Num2 * 2));
	}
}