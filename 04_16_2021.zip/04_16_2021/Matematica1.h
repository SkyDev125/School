#pragma once
/*ENTRADA: dois números inteiros
PROCESSAMENTO: operações matemáticas
Soma dos dois números
Subtração dos dois números
Multiplicado dos dois números
Divisão dos dois números
Potencia dos dois números (primeiro número elevado pelo segundo número)
Raiz quadrada dos dois números
SAIDA: Exiba na tela os resultados de todas as operações também utilizando chamada de funções
- cabeçalho Matematica.h  protótipos das funções 
-arquivo Matematica.cpp para ser a implementação do arquivo de
cabeçalho Matematica.h 
- arquivo ProgramaMatematico.cpp que conteráfunção main( ) e será o
ponto de partida deste programa.
*/
int Soma(int num1, int num2);
int Subtracao(int num1, int num2);
int Multiplicacao(int num1, int num2);
float Divisao(int num1, int num2);
double Potencia(double num1, double num2);
float RaizQuadrada(int num);
