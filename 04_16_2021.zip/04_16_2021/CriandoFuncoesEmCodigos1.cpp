#include <iostream>
#include <locale.h>
#include "FuncoesMenu.h"
#include "FuncoesMenu.cpp"

int main()
{
	//Exibe o menu opções chamando a função Exibir Menu
	ExibirMenu();
	system("PAUSE");
	return 0;
}