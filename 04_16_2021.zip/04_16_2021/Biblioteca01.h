#pragma once
namespace mat01
{
	float Soma(int Num1, int Num2)
	{
		return (Num1 + Num2);
	}
}